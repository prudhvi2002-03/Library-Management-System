# library-management-system


### environment variables
```
1. DATABASE
2. JWT_COOKIE
3. JWT_SECRET
4. DATABASE_PASSWORD
```

# Main-Page
![text](public/img/main_page.png)